########## goatgrass data analysis code ########
#########  by Rebecca Nelson #############
##### for Nelson, Dritz, Valdovinos, and Aigner 2022 ###
### The Restoration of Serpentine Plant-Pollinator Mutualisms ###
### Biological Invasions ###
######################################


######## load required packages ########
#library(AER)
#require(emmeans)
#require(magrittr)
#library(tidyverse)
#require(lubridate)
#require(bipartite)
#require(vegan)
#require(FSA)
#library(ape)
#library(rstatix)
#require(lme4)
#library(ggpubr)
#library(sjPlot)
#library(sjstats)
#library(blmeco)
#require(blme)
#library("GGally")
#library("maxnodf")

##### upload, clean, and merge data #####

## plant data ###
paul_cov <-read.csv('paul_plant_cover_2011_2012.csv') #2011 and 2012

#rename to correct lomatium species
paul_cov <- paul_cov %>% 
  rename(
    LOHO = LOCI
  )


#make a combined year/plot column for paul_cov
paul_cov$Sample_ID <- paste(paul_cov$PLOT,paul_cov$YEAR)


#rename columns in plant data that correspond to columns in pollinator data:
paul_cov$Treatment <- paul_cov$TRT
paul_cov$Plot <- paul_cov$PLOT
paul_cov$Year <- paul_cov$YEAR

#subset by year
paul_cov_2011 <- paul_cov %>% subset(YEAR == "2011")
paul_cov_2012 <- paul_cov %>% subset(YEAR == "2012")

## poll data ##
goatgrass_clean <- read.csv("data.csv")



### plot level ###
#plot level so each plot has a total
paul_richness_data_11 <- goatgrass_clean %>% subset(Year == 2011) %>% group_by(Plot,Treatment, Type, Method, Year) %>% summarize (Plot_Richness = length(unique(ARTH))) 
paul_richness_data_12 <- goatgrass_clean %>% subset(Year == 2012) %>% group_by(Plot,Treatment, Type, Method, Year) %>% summarize (Plot_Richness = length(unique(ARTH))) 
paul_richness_data_13 <- goatgrass_clean %>% subset(Year == 2013) %>% group_by(Plot,Treatment, Type, Method, Year) %>% summarize (Plot_Richness = length(unique(ARTH))) 
paul_richness_data <- rbind(paul_richness_data_11, paul_richness_data_12, paul_richness_data_13)

total_abund_plot_11 <- goatgrass_clean %>% subset(Year == 2011) %>% group_by(Plot, Year) %>% summarise(Abundance = sum(Interaction_Weight))
total_abund_plot_12 <- goatgrass_clean %>% subset(Year == 2012) %>% group_by(Plot, Year) %>% summarise(Abundance = sum(Interaction_Weight))
total_abund_plot_13 <- goatgrass_clean %>% subset(Year == 2013) %>% group_by(Plot, Year) %>% summarise(Abundance = sum(Interaction_Weight))
total_abund_plot <- rbind(total_abund_plot_11, total_abund_plot_12, total_abund_plot_13)


paul_comm_plot <- left_join(paul_richness_data, total_abund_plot, by=c("Plot", "Year"))

paul_abundance_data_11 <- goatgrass_clean %>% subset(Year == 2011) %>% group_by(Plot, ARTH, Year) %>% summarise(Abundance = sum(Interaction_Weight)) 
shannon_11 <- paul_abundance_data_11 %>% group_by(Plot, Year) %>% summarise(shannon = -sum(Abundance/sum(Abundance)*log(Abundance/sum(Abundance))))

paul_abundance_data_12 <- goatgrass_clean %>% subset(Year == 2012) %>% group_by(Plot, ARTH, Year) %>% summarise(Abundance = sum(Interaction_Weight)) 
shannon_12 <- paul_abundance_data_12 %>% group_by(Plot, Year) %>% summarise(shannon = -sum(Abundance/sum(Abundance)*log(Abundance/sum(Abundance))))

paul_abundance_data_13 <- goatgrass_clean %>% subset(Year == 2013) %>% group_by(Plot, ARTH, Year) %>% summarise(Abundance = sum(Interaction_Weight)) 
shannon_13 <- paul_abundance_data_13 %>% group_by(Plot, Year) %>% summarise(shannon = -sum(Abundance/sum(Abundance)*log(Abundance/sum(Abundance))))
shannon <- rbind(shannon_11, shannon_12, shannon_13)

paul_comm_plot <- left_join(paul_comm_plot, shannon, by=c("Plot", "Year"))



## scale year:
paul_cov$Year.s <- scale(paul_cov$Year)
paul_comm_plot$Year.s <- scale(paul_comm_plot$Year)


#unique(paul_richness_data_11$Plot)
zero_11 <- plot_richness_zeros %>% filter(Year == 2011) 
zero_12 <- plot_richness_zeros %>% filter(Year == 2011) 
zero_13 <- plot_richness_zeros %>% filter(Year == 2011) 
#unique(zero_11$Plot)

zeros <- data.frame(Year = 2011,             
                    Plot = 606)


#add zeros to paul_comm_plot:
zero_11 <- zero_11 %>% filter(Plot == 606) %>% mutate(Abundance = 0)

#2012: (606,617,635,643,658,706))

total_zero <- rbind(zero_11, zero_12, zero_13)

paul_comm_plot <- left_join(paul_comm_plot, total_zero, by=c("Plot", "Year", "Treatment", "Plot_Richness", "Abundance")) 


### Ground nesting bee total abundance ###
#note: load and merge data from nesting_habits
ground <- goatgrass_clean %>% subset(NEST == "Ground")

ground_abund_plot_11 <- ground %>% subset(Year == 2011) %>%   group_by(Plot, Year, Treatment) %>% summarise(Ground_Abundance = sum(Interaction_Weight))
ground_abund_plot_12 <- ground %>% subset(Year == 2012) %>%   group_by(Plot, Year, Treatment) %>% summarise(Ground_Abundance = sum(Interaction_Weight))
ground_abund_plot_13 <- ground %>% subset(Year == 2013) %>%   group_by(Plot, Year, Treatment) %>% summarise(Ground_Abundance = sum(Interaction_Weight))

ground_abund_plot <- rbind(ground_abund_plot_11, ground_abund_plot_12, ground_abund_plot_13)

## scale year:
ground_abund_plot$Year.s <- scale(ground_abund_plot$Year)


ground_abund_plot <- ground_abund_plot %>% 
  mutate(
    Type = case_when(
      Treatment == "CON" ~ "Control",
      TRUE ~ "Restored"
    )) 

temp <- ground_abund_plot %>% dplyr::select(Ground_Abundance, Type, Plot, Year)

#combine ground and overall abundance 
ground_abund_plot_full <- left_join(paul_comm_plot, temp, by=c("Plot", "Year" , "Type"))
ground_abund_plot_full[is.na(ground_abund_plot_full)] <- 0

ground_abund_plot_full <- ground_abund_plot_full %>% mutate(ground_prop = Ground_Abundance/Abundance) #proportion of ground nesting bees observed relative to total number of bees observed in a plot 

##### Part 1 plants ###########

###### Does goatgrass cover differ between restored vs control ####
#include year effects in model


mod_aetr <- glm(AETR ~ Type*Year.s, data = paul_cov) 
plot(mod_aetr) 
summary(mod_aetr)

### Does LACA cover differ by treatment? #######
mod_laca <- glm(LACA ~ Type*Year.s, data = paul_cov) 
plot(mod_laca) 
summary(mod_laca)


### Does total poll used native forb cover differ by treatment? ####
poll_forb <- paul_cov %>% dplyr::select(Year, Type, Treatment, Year.s, Plot, LACA, DICA, DEVA, GITR, TRER, TRAL, NAPU,  TRFU, NAJE, GRCA, AGHE, RACA, MIDO, HOVI, CAPA, HECO, LOHO, LIBI, VIDO, LOWR, ERNU)

poll_forb$Total <- rowSums(poll_forb[ , c("LACA", "DICA", "DEVA", "GITR", "TRER", "TRAL", "TRFU", "NAJE", "GRCA", "NAPU", "AGHE", "RACA", "MIDO", "HOVI", "CAPA", "HECO", "LOHO", "LIBI", "VIDO", "LOWR", "ERNU")]) 

mod_total <- glm(Total ~ Type*Year.s, data = poll_forb) 
plot(mod_total) 

summary(mod_total)


## Does total annual grass cover differ between restored vs control? ###
grass <- paul_cov %>% dplyr::select(Year, Type, Treatment, Year.s, Plot, AETR, BRHO, LOMU, VUMI)

grass$Total <- rowSums(grass[ , c("AETR", "BRHO", "LOMU", "VUMI")]) 



mod_total_grass <- glm(Total ~ Type*Year.s, data = grass) 
plot(mod_total_grass) 
summary(mod_total_grass)

#### Plant diversity and abundance by plot ####
#total preferred forb cover poll_forb$ Total


long_forb <-  pivot_longer(poll_forb, cols = -c("Treatment", "Plot", "Year", "Type", "Year.s"), names_to = "Plant_Species", values_to = "Cover")

poll_forb <- poll_forb %>% dplyr::select(Plot, Year, Type, Total, LACA)

forb_div <- long_forb %>% group_by(Plot, Type, Year) %>% subset(Cover != 0) %>% summarize(Forb_Richness = length(unique(Plant_Species))) #total preferred forb diversity by plot all years combined 

poll_forb$Plot <- as.character(poll_forb$Plot)
forb_div$Plot <- as.character(forb_div$Plot)
paul_comm_plant <- left_join(paul_comm_plot, poll_forb, by=c("Plot", "Year", "Type"))
plant <- left_join(paul_comm_plant, forb_div, by=c("Plot","Year", "Type"))
forb_div <- left_join(paul_comm_plot, forb_div, by=c("Plot", "Year", "Type"))

##### Part 2 Pollinators ######### 

### Does pollinator richness vary by restored vs control? ######

td <- glm(Plot_Richness ~ Type*Year.s, family = poisson, data=paul_comm_plot) 
dispersiontest(td) 
plot(fitted(td),resid(td)) 
qqnorm(resid(td)) 
summary(td)


td_1 <- glm(Plot_Richness ~ Type + LACA, family = poisson, data=paul_comm_plant) 
dispersiontest(td_1) 
plot(fitted(td_1),resid(td_1)) 
qqnorm(resid(td_1)) 
summary(td_1)


#with just restored 
restored <- paul_comm_plant %>% subset(Type == "Restored")
td_1 <- glm(Plot_Richness ~ LACA, family = poisson, data=restored) 
dispersiontest(td_1) 
plot(fitted(td_1),resid(td_1)) 
qqnorm(resid(td_1)) 
summary(td_1)


#with just restored 
restored <- paul_comm_plant %>% subset(Type == "Restored")
td_2 <- glm(Plot_Richness ~ Total, family = poisson, data=restored) 
dispersiontest(td_2) 
plot(fitted(td_2),resid(td_2)) 
qqnorm(resid(td_2)) 
summary(td_2)


restored_2 <- forb_div %>% subset(Type == "Restored")

td_3 <- glm(Plot_Richness ~ Forb_Richness, family = poisson, data=restored_2) 
dispersiontest(td_3) 
plot(fitted(td_3),resid(td_3)) 
qqnorm(resid(td_3)) 
summary(td_3)


### Does pollinator shannon index vary by type? ####

sh <- glm(shannon ~ Type*Year.s, data=paul_comm_plot) 
plot(sh)
plot(fitted(sh),resid(sh)) 
qqnorm(resid(sh)) 
summary(sh)


## Does pollinator total abundance vary by type? ####


abund <- glm.nb(Abundance ~ Type*Year.s, data=paul_comm_plot) 
plot(fitted(abund),resid(abund)) 
qqnorm(resid(abund))
plot(abund)
summary(abund)


#with just restored 
restored <- paul_comm_plant %>% subset(Type == "Restored")
abund_1 <- glm.nb(Abundance ~ LACA, data=restored) 
plot(fitted(abund_1),resid(abund_1)) 
qqnorm(resid(abund_1)) # looks relatively normal 
summary(abund_1)




abund_1 <- glm.nb(Abundance ~ Type + Total, data=paul_comm_plant) 
plot(fitted(abund_1),resid(abund_1)) 
qqnorm(resid(abund_1)) 
summary(abund_1)


#with just restored 
restored <- paul_comm_plant %>% subset(Type == "Restored")
abund_2 <- glm.nb(Abundance ~ Total, data=restored) 
plot(fitted(abund_2),resid(abund_2)) 
qqnorm(resid(abund_2)) 
summary(abund_2)

#with just restored 
restored_2 <- forb_div %>% subset(Type == "Restored")
restored_2 <- plant %>% subset(Type == "Restored")

abund_3 <- glm.nb(Abundance ~ Forb_Richness, data=restored_2) 
plot(fitted(abund_3),resid(abund_2)) 
qqnorm(resid(abund_3)) 
summary(abund_3)

abund_3 <- glm.nb(Abundance ~ Forb_Richness + Total, data=restored_2) 
plot(fitted(abund_3),resid(abund_3)) 
qqnorm(resid(abund_3)) 
summary(abund_3)

paul_comm_plant %>% ggplot(aes(x = Total, y = Abundance, color = Type)) +
  geom_point() + theme_classic() 

paul_comm_plant %>% ggplot(aes(x = Total, y = Plot_Richness, color = Type)) +
  geom_point() + theme_classic() 

paul_comm_plant %>% ggplot(aes(x = LACA, y = Abundance, color = Type)) +
  geom_point() + theme_classic() 

paul_comm_plant %>% ggplot(aes(x = LACA, y = Plot_Richness, color = Type)) +
  geom_point() + theme_classic() 

forb_div %>% ggplot(aes(x = Forb_Richness, y = Abundance, color = Type)) +
  geom_point() + theme_classic() 

paul_comm_plant %>% ggplot(aes(x = Forb_Richness, y = Plot_Richness, color = Type)) +
  geom_point() + theme_classic() 



## Does total abundance of ground nesting bees vary by type? #####

#redid with zeros--now overdispersed so changed to negative binomial
ground_abund <- glm.nb(Ground_Abundance ~ Type*Year.s, data=ground_abund_plot_full)
plot(fitted(ground_abund),resid(ground_abund)) 
qqnorm(resid(ground_abund)) 
plot(ground_abund) 

summary(ground_abund) 

ground_abund <- glm(ground_prop ~ Type*Year.s, data=ground_abund_plot_full)
plot(fitted(ground_abund),resid(ground_abund)) 
qqnorm(resid(ground_abund)) 
plot(ground_abund) 
summary(ground_abund) 



#### Community Composition ########
### Format data for PERMANOVA 

paul_abundance_data <- goatgrass_clean %>%  group_by(Plot, ARTH) %>% summarise(Abundance = sum(Interaction_Weight))  

paul_abundance_data_11 <- goatgrass_clean %>% dplyr::filter(Year == 2011) %>%  group_by(Plot, ARTH) %>% summarise(Abundance = sum(Interaction_Weight)) 

paul_abundance_data_12 <- goatgrass_clean %>% dplyr::filter(Year == 2012) %>%  group_by(Plot, ARTH) %>% summarise(Abundance = sum(Interaction_Weight)) 

paul_abundance_data_13 <- goatgrass_clean %>% dplyr::filter(Year == 2013) %>%  group_by(Plot, ARTH) %>% summarise(Abundance = sum(Interaction_Weight)) 


paul_poll_perm <- paul_abundance_data %>% group_by(Plot) %>% pivot_wider(names_from = ARTH, values_from = Abundance) 
paul_poll_perm_11 <- paul_abundance_data_11 %>% group_by(Plot) %>% pivot_wider(names_from = ARTH, values_from = Abundance) 
paul_poll_perm_12 <- paul_abundance_data_12 %>% group_by(Plot) %>% pivot_wider(names_from = ARTH, values_from = Abundance) 
paul_poll_perm_13 <- paul_abundance_data_13 %>% group_by(Plot) %>% pivot_wider(names_from = ARTH, values_from = Abundance) 

#convert NAs to 0s
paul_poll_perm[is.na(paul_poll_perm)] <- 0
paul_poll_perm_11[is.na(paul_poll_perm_11)] <- 0
paul_poll_perm_12[is.na(paul_poll_perm_12)] <- 0
paul_poll_perm_13[is.na(paul_poll_perm_13)] <- 0

##make plot by treatment dataframes 
#paul_treatments <- read.csv("Treatment.csv") 
#paul_treatments<- paul_treatments[-c(4),] #delete plot 606 which never had interaction data collected for it
#paul_treatments = subset(paul_treatments, select = -c(Plot_Notes))

#convert plot to a character vector for paul_treatments
paul_treatments$Plot <- as.character(paul_treatments$Plot)

#left join to add treatment info into community matrix:
paul_poll_perm <- left_join(paul_poll_perm, paul_treatments, by = c("Plot"))
paul_poll_perm <-paul_poll_perm %>% 
  mutate(
    Type = case_when(
      Treatment == "CON" ~ "Control",
      TRUE ~ "Restored"
    )) 

paul_treatments$Plot <- as.character(paul_treatments$Plot)
paul_poll_perm_11 <- left_join(paul_poll_perm_11, paul_treatments, by = c("Plot"))
paul_poll_perm_11 <-paul_poll_perm_11 %>% 
  mutate(
    Type = case_when(
      Treatment == "CON" ~ "Control",
      TRUE ~ "Restored"
    )) 

paul_poll_perm_12 <- left_join(paul_poll_perm_12, paul_treatments, by = c("Plot"))
paul_poll_perm_12 <-paul_poll_perm_12 %>% 
  mutate(
    Type = case_when(
      Treatment == "CON" ~ "Control",
      TRUE ~ "Restored"
    )) 

paul_poll_perm_13 <- left_join(paul_poll_perm_13, paul_treatments, by = c("Plot"))
paul_poll_perm_13 <-paul_poll_perm_13 %>% 
  mutate(
    Type = case_when(
      Treatment == "CON" ~ "Control",
      TRUE ~ "Restored"
    )) 



## move data into wide format:
paul_abundance_data <- goatgrass_clean %>%  group_by(Plot, ARTH) %>% summarise(Abundance = sum(Interaction_Weight)) 
community_paul <- paul_abundance_data %>% group_by(Plot) %>% pivot_wider(names_from = ARTH, values_from = Abundance)

paul_abundance_data_11 <- goatgrass_clean %>% dplyr::filter(Year == 2011) %>%  group_by(Plot, ARTH) %>% summarise(Abundance = sum(Interaction_Weight)) 
community_paul_11 <- paul_abundance_data_11 %>% group_by(Plot) %>% pivot_wider(names_from = ARTH, values_from = Abundance)

paul_abundance_data_12 <- goatgrass_clean %>% dplyr::filter(Year == 2012) %>%  group_by(Plot, ARTH) %>% summarise(Abundance = sum(Interaction_Weight)) 
community_paul_12 <- paul_abundance_data_12 %>% group_by(Plot) %>% pivot_wider(names_from = ARTH, values_from = Abundance)

paul_abundance_data_13 <- goatgrass_clean %>% dplyr::filter(Year == 2013) %>%  group_by(Plot, ARTH) %>% summarise(Abundance = sum(Interaction_Weight)) 
community_paul_13 <- paul_abundance_data_13 %>% group_by(Plot) %>% pivot_wider(names_from = ARTH, values_from = Abundance)

#drop site from the df
community_paul <- as.data.frame(community_paul)
rownames(community_paul) = community_paul$Plot
community_paul = subset(community_paul, select = -c(Plot))

community_paul_11 <- as.data.frame(community_paul_11)
rownames(community_paul_11) = community_paul_11$Plot
community_paul_11 = subset(community_paul_11, select = -c(Plot))

community_paul_12 <- as.data.frame(community_paul_12)
rownames(community_paul_12) = community_paul_12$Plot
community_paul_12 = subset(community_paul_12, select = -c(Plot))

community_paul_13 <- as.data.frame(community_paul_13)
rownames(community_paul_13) = community_paul_13$Plot
community_paul_13 = subset(community_paul_13, select = -c(Plot))

#convert NAs to 0s
community_paul[is.na(community_paul)] <- 0

community_paul_11[is.na(community_paul_11)] <- 0

community_paul_12[is.na(community_paul_12)] <- 0

community_paul_13[is.na(community_paul_13)] <- 0

##make plot by treatment dataframes 
paul_treatments <- read.csv("Treatment.csv", row.names = 1) 
paul_treatments<- paul_treatments[-c(4),] #delete plot 606 which never had interaction data collected for it
paul_treatments = subset(paul_treatments, select = -c(Plot_Notes))
paul_treatments <-paul_treatments %>% 
  mutate(
    Type = case_when(
      Treatment == "CON" ~ "Control",
      TRUE ~ "Restored"
    )) 



### Analysis in vegan 

## Paul
## format data 
paul.matrix <- as.matrix(community_paul) #pollinator community
paul.matrix.11 <- as.matrix(community_paul_11)
paul.matrix.12 <- as.matrix(community_paul_12)
paul.matrix.13 <- as.matrix(community_paul_13)
###
## transform data:
#Use square root or proportions to minimize influence of most abundant groups.
paul.mat<-sqrt(paul.matrix) #square root transform

paul.mat.11<-sqrt(paul.matrix.11) 
paul.mat.12<-sqrt(paul.matrix.12)
paul.mat.13<-sqrt(paul.matrix.13) 

#Create a dissimilarity matrix:
paul.dist<-vegdist(paul.mat, method='bray')
paul.dist.11 <-vegdist(paul.mat.11, method='bray')
paul.dist.12 <-vegdist(paul.mat.12, method='bray')
paul.dist.13 <-vegdist(paul.mat.13, method='bray')

#Do restoration treatments (combined) differ from control? 
set.seed(36) #reproducible results
paul.perm.poll <-adonis2(paul.dist~Type, data=paul_poll_perm, permutations = 999, method="bray")
paul.perm.poll


set.seed(36) #reproducible results
paul.perm.poll.11 <-adonis2(paul.dist.11~Type, data=paul_poll_perm_11, permutations = 999, method="bray")
paul.perm.poll.11
               

set.seed(36) #reproducible results
paul.perm.poll.12 <-adonis2(paul.dist.12~Type, data=paul_poll_perm_12, permutations = 999, method="bray")
paul.perm.poll.12
  

set.seed(36) #reproducible results
paul.perm.poll.13 <-adonis2(paul.dist.13~Type, data=paul_poll_perm_13, permutations = 999, method="bray")
paul.perm.poll.13
           


paul.dispersion<-betadisper(paul.dist, group=paul_poll_perm$Type)
permutest(paul.dispersion)

plot(paul.dispersion, hull=FALSE, ellipse=TRUE) ##sd ellipse


paul.dispersion<-betadisper(paul.dist.11, group=paul_poll_perm_11$Type)
permutest(paul.dispersion)
           
plot(paul.dispersion, hull=FALSE, ellipse=TRUE) ##sd ellipse


paul.dispersion<-betadisper(paul.dist.12, group=paul_poll_perm_12$Type)
permutest(paul.dispersion)
  
plot(paul.dispersion, hull=FALSE, ellipse=TRUE) ##sd ellipse

paul.dispersion<-betadisper(paul.dist.13, group=paul_poll_perm_13$Type)
permutest(paul.dispersion)
 
plot(paul.dispersion, hull=FALSE, ellipse=TRUE) ##sd ellipse

### Part 3 plant-pollinator network structure #######

#are there differences in network structure between treatments? 

## Generate networks for each Paul treatment: #########

#### control matrix across all years ----
interactions_CON <- goatgrass_clean %>% filter(goatgrass_clean$Type == "Control") 

interactions_CON <- table(interactions_CON$ARTH, interactions_CON$SUB)

bee.plant.CON <- as.matrix(interactions_CON)

bee.plant.sorted.CON <- sortweb(bee.plant.CON)
plotweb(bee.plant.sorted.CON, method = "normal", labsize = .45, text.rot=90, col.high = c("gold1","grey10", "firebrick4","grey10", "grey10","grey10", "grey10","grey10", "grey10","grey10"))

#write.table(t(interactions_CON),"/Users/Becca/Desktop/Harrison Lab/Goatgrass Data/goatgrass//control_network.txt", row.names = FALSE, col.names = FALSE)
#write.table(t(interactions_CON),"/Users/Becca/Desktop/Harrison Lab/Goatgrass Data/goatgrass//control_network.txt")

## restored matrix across all years----
interactions_R <- goatgrass_clean %>% filter(goatgrass_clean$Type == "Restored") 

interactions_R <- table(interactions_R$ARTH, interactions_R$SUB)

bee.plant.R <- as.matrix(interactions_R)

bee.plant.sorted.R <- sortweb(bee.plant.R)
plotweb(bee.plant.sorted.R, method = "normal", labsize = .45, text.rot=90,  col.high = c("gold1","grey10", "grey10","grey10", "grey10","grey10", "grey10","grey10", "grey10","grey10", "grey10","grey10", "grey10","grey10", "grey10","grey10", "grey10","grey10"))

#write.table(t(interactions_R),"/Users/Becca/Desktop/Harrison Lab/Goatgrass Data/goatgrass//restored_network.txt", row.names = FALSE, col.names = FALSE)

#write.table(t(interactions_R),"/Users/Becca/Desktop/Harrison Lab/Goatgrass Data/goatgrass//restored_network.txt")


## Combined Network ------
interactions <- goatgrass_clean  

interactions <- table(interactions$ARTH, interactions$SUB)

bee.plant <- as.matrix(interactions)

bee.plant.sorted <- sortweb(bee.plant)
plotweb(bee.plant.sorted, method = "normal", labsize = .45, text.rot=90,  col.high = c("gold1","grey10", "grey10","grey10", "grey10","grey10", "grey10","grey10", "grey10","grey10", "grey10","grey10", "grey10","grey10", "grey10","grey10", "grey10","grey10"))

#write.table(t(interactions),"/Users/Becca/Desktop/Harrison Lab/Goatgrass Data/goatgrass//both_network.nonames.txt", row.names = FALSE, col.names = FALSE)
#write.table(t(interactions),"/Users/Becca/Desktop/Harrison Lab/Goatgrass Data/goatgrass//both_network.txt")

#write.table(t(interactions_R),"/Users/Becca/Desktop/Harrison Lab/Goatgrass Data/goatgrass//restored_network.txt")

#### calculate nestedness using the maxnodf package -----------

#### NODFc ##
NODFc(bee.plant.CON) 

NODFc(bee.plant.R) 


# Read all the interaction network matrices into a list
Paul_webs <- list(bee.plant.CON, bee.plant.R)

P_webs.names <- c("Control", "Restored") 

names(Paul_webs) <- P_webs.names

# View data 
lapply(Paul_webs, head, n = 2L) 

## Does weighted nestedness vary by treatment? #####

## Does binary nestedness vary by treatment? #####
# Calculate network metric nestedness for all plant-pollinator sites
net.metrics.bnest.p <- lapply(Paul_webs, networklevel, index = 'NODF') 

## Does number of shared partners for plants vary by treatment? ###
net.metrics.partners.hl.p <- lapply(Paul_webs, networklevel, index = 'mean number of shared partners', level = "higher")

## Does number of shared partners for pollinators vary by treatment? ###
net.metrics.partners.ll.p <- lapply(Paul_webs, networklevel, index = 'mean number of shared partners', level = "lower")

## Does plant niche overlap vary by treatment? ###
net.metrics.niche.hl.p <- lapply(Paul_webs, networklevel, index = 'niche overlap', level = "higher")
# in the case our our networks, plants were input as the 'higher' level

## Does pollinator niche overlap vary by treatment? ###
net.metrics.niche.ll.p <- lapply(Paul_webs, networklevel, index = 'niche overlap', level = "lower")
# in the case our our networks, pollinators were input as the 'lower' level

#network analysis 
set.seed(23)
net.nulls.swap_p <- lapply(Paul_webs, permatswap, method = "quasiswap", times = 1000)
net.nulls.swap_p$Control <- net.nulls.swap_p$Control$perm 
net.nulls.swap_p$Restored <- net.nulls.swap_p$Restored$perm 


# Null distribution function for binary nestedness - calculates the network nestedness for each null (using a particular null method) for each site 
net.null.bnest.p = function(nulls){
  net.null.metric <- list()
  for (i in 1:length(nulls)) {
    net.null.metric[[i]] = do.call('rbind', 
                                   lapply(nulls[[i]], networklevel, index = 'NODF'))
  }
  names(net.null.metric) <- P_webs.names
  return(net.null.metric)
}

# Null distribution function for niche overlap - calculates the network horn index for each null (using a particular null method) for each site 
net.null.niche.ll.p = function(nulls){
  net.null.metric <- list()
  for (i in 1:length(nulls)) {
    net.null.metric[[i]] = do.call('rbind', 
                                   lapply(nulls[[i]], networklevel, index = 'niche overlap', level = "lower"))
  }
  names(net.null.metric) <- P_webs.names
  return(net.null.metric)
}

net.null.niche.hl.p = function(nulls){
  net.null.metric <- list()
  for (i in 1:length(nulls)) {
    net.null.metric[[i]] = do.call('rbind', 
                                   lapply(nulls[[i]], networklevel, index = 'niche overlap', level = "higher"))
  }
  names(net.null.metric) <- P_webs.names
  return(net.null.metric)
}

### Shared Partners
net.null.partners.ll.p = function(nulls){
  net.null.metric <- list()
  for (i in 1:length(nulls)) {
    net.null.metric[[i]] = do.call('rbind', 
                                   lapply(nulls[[i]], networklevel, index = 'mean number of shared partners', level = "lower"))
  }
  names(net.null.metric) <- P_webs.names
  return(net.null.metric)
}


net.null.partners.hl.p = function(nulls){
  net.null.metric <- list()
  for (i in 1:length(nulls)) {
    net.null.metric[[i]] = do.call('rbind', 
                                   lapply(nulls[[i]], networklevel, index = 'mean number of shared partners', level = "higher"))
  }
  names(net.null.metric) <- P_webs.names
  return(net.null.metric)
}

set.seed(23)
swap.bnest.p <- net.null.bnest.p(net.nulls.swap_p)
swap.niche.ll.p <- net.null.niche.ll.p(net.nulls.swap_p)
swap.niche.hl.p <- net.null.niche.hl.p(net.nulls.swap_p)
swap.partners.ll.p <- net.null.partners.ll.p(net.nulls.swap_p)
swap.partners.hl.p <- net.null.partners.hl.p(net.nulls.swap_p)


# Z-score function for comparing different networks
net.zscore = function(obsval, nullval) {
  (obsval - mean(nullval))/sd(nullval)  
} 



# Function that perform z-score calculation of binary nestedness using the observed and null networks
bnest.zscore.p = function(nulltype){
  net.bnest.zscore <- list() 
  for(i in 1:length(net.metrics.bnest.p)){
    net.bnest.zscore[[i]] = net.zscore(net.metrics.bnest.p[[i]]['NODF'], 
                                       nulltype[[i]][ ,'NODF'])
  }
  names(net.bnest.zscore) <- P_webs.names
  return(net.bnest.zscore)
}



# Function that perform z-score calculation of horn index niche overlap s using the observed and null networks
niche.ll.zscore.p = function(nulltype){
  net.niche.ll.zscore <- list() 
  for(i in 1:length(net.metrics.niche.ll.p)){
    net.niche.ll.zscore[[i]] = net.zscore(net.metrics.niche.ll.p[[i]]['niche.overlap.LL'], 
                                          nulltype[[i]][,'niche.overlap.LL'])
  }
  names(net.niche.ll.zscore) <- P_webs.names
  return(net.niche.ll.zscore)
}

niche.hl.zscore.p = function(nulltype){
  net.niche.hl.zscore <- list() 
  for(i in 1:length(net.metrics.niche.hl.p)){
    net.niche.hl.zscore[[i]] = net.zscore(net.metrics.niche.hl.p[[i]]['niche.overlap.HL'], 
                                          nulltype[[i]][,'niche.overlap.HL'])
  }
  names(net.niche.hl.zscore) <- P_webs.names
  return(net.niche.hl.zscore)
}


##shared partners z score:
partners.ll.zscore.p = function(nulltype){
  net.partners.ll.zscore <- list() 
  for(i in 1:length(net.metrics.partners.ll.p)){
    net.partners.ll.zscore[[i]] = net.zscore(net.metrics.partners.ll.p[[i]]['mean.number.of.shared.partners.LL'], 
                                             nulltype[[i]][,'mean.number.of.shared.partners.LL'])
  }
  names(net.partners.ll.zscore) <- P_webs.names
  return(net.partners.ll.zscore)
}

partners.hl.zscore.p = function(nulltype){
  net.partners.hl.zscore <- list() 
  for(i in 1:length(net.metrics.partners.hl.p)){
    net.partners.hl.zscore[[i]] = net.zscore(net.metrics.partners.hl.p[[i]]['mean.number.of.shared.partners.HL'], 
                                             nulltype[[i]][,'mean.number.of.shared.partners.HL'])
  }
  names(net.partners.hl.zscore) <- P_webs.names
  return(net.partners.hl.zscore)
}



swap.bnest.zscore.p <- bnest.zscore.p(swap.bnest.p)
swap.niche.ll.zscore.p <- niche.ll.zscore.p(swap.niche.ll.p)
swap.niche.hl.zscore.p <- niche.hl.zscore.p(swap.niche.hl.p)
swap.partners.ll.zscore.p <- partners.ll.zscore.p(swap.partners.ll.p)
swap.partners.hl.zscore.p <- partners.hl.zscore.p(swap.partners.hl.p)




# Function that adds p-values according to the obtained z-scores
add.pvalues = function(net.metric.zscore){
  # Change the output class from list of a list into a matrix
  net.metric.zscore <- do.call('rbind', net.metric.zscore) 
  
  # Convert z-scores to p-values (two-sided)
  net.metric.pvalue <- 2*pnorm(-abs(net.metric.zscore))
  
  # Change matrix into a dataframe
  net.metric.pvalue <- as.data.frame(as.table(net.metric.pvalue))
  colnames(net.metric.pvalue) <- c('treatment', 'metric', 'pvalue')
  
  net.metric.pvalue <- within(net.metric.pvalue, {
    significance <- ifelse(pvalue <= 0.001, "***", 
                           ifelse(pvalue <= 0.01, "**",
                                  ifelse(pvalue <= 0.05, "*", "not significant")))
  })
  return(net.metric.pvalue)
} 


# Add the p-values to our nestedness results
swap.test.bnest.p <- add.pvalues(swap.bnest.zscore.p)

# Add the p-values to our niche overlap results
swap.test.niche.ll.p <- add.pvalues(swap.niche.ll.zscore.p)
swap.test.niche.hl.p <- add.pvalues(swap.niche.hl.zscore.p)

##shared partners:
swap.test.partners.ll.p <- add.pvalues(swap.partners.ll.zscore.p)
swap.test.partners.hl.p <- add.pvalues(swap.partners.hl.zscore.p)

#print results 
print(swap.test.bnest.p) 
print(swap.test.niche.ll.p)
print(swap.test.niche.hl.p) 
print(swap.test.partners.ll.p)  
print(swap.test.partners.hl.p) 



## Which plant species contribute the most to nestedness? ###
set.seed(12)
con_nest <- nestedcontribution(bee.plant.CON, nsimul = 1000)

set.seed(12)
rest_nest <- nestedcontribution(bee.plant.R, nsimul = 1000)

#2*pnorm(-abs(1.404))
#2*pnorm(-abs(5.4434088))

### Does nestedness contribution correspond to plant abundance independent of network? plant cover data #############################

long_cov <- paul_cov %>% 
  pivot_longer(cols = -c("PLOT", "TRT", "TC1", "OBS", "YEAR", "Sample_ID", "Treatment", "Plot", "Year", "Type"), names_to = "Plant_Species", values_to = "Cover")

rest_nest <- as.data.frame(rest_nest$`higher level`)
rest_nest <- tibble::rownames_to_column(rest_nest, "Plant_Species")

con_nest <- as.data.frame(con_nest$`higher level`)
con_nest <- tibble::rownames_to_column(con_nest, "Plant_Species")

#write.csv(con_nest,"/Users/Becca/Desktop/Harrison Lab/Goatgrass Data/goatgrass/goatgrass_cleaned//con.nest.csv", row.names = TRUE)
#write.csv(rest_nest,"/Users/Becca/Desktop/Harrison Lab/Goatgrass Data/goatgrass/goatgrass_cleaned//rest.nest.csv", row.names = TRUE)

#con_nest <-read_csv("con_nest.csv") 
#rest_nest <-read_csv("rest_nest.csv") 

## does ind contribution to nestedness for each plant species correlate with abundance indep of network for restored network? 
cover_rest <- left_join(rest_nest, long_cov, by=c("Plant_Species"))

cover_rest %>% filter(Type == "Restored") %>%  ggplot(aes(x = Cover, y = nestedcontribution, color = Plant_Species)) +
  geom_point() + theme_classic() #note this gives the full range of cover values for each species with the network level nestedness value

cover_rest_clean <- cover_rest %>% dplyr::select("Plant_Species", "Cover", "Type", "nestedcontribution") %>% filter(Type == "Restored") %>% group_by(Plant_Species, nestedcontribution) %>% summarize(mean_cover = mean(Cover, na.rm=TRUE)) #pools years together note cover for 2011 and 2012 while nestedness value for 2011-2013

cover_rest_clean %>% ggplot(aes(x = mean_cover, y = nestedcontribution, color = Plant_Species)) + geom_point() + geom_abline()+ theme_classic() 



# does ind contribution to nestedness for each plant species correlate with abundance indep of network for control network? 
cover_con <- left_join(con_nest, long_cov, by=c("Plant_Species"))



## investigate these relationships statistically 
mod_con <- glm(nestedcontribution ~ mean_cover, data = cover_con_clean) 
plot(mod_con) 
summary(mod_con)


mod_rest <- glm(nestedcontribution ~ mean_cover, data = cover_rest_clean) 
plot(mod_rest) 
summary(mod_rest)


## Young, Valdovinos, and Newman contains reference code for Bayesian inference:
#Young TP, Petersen DA, Clary JJ (2005) The ecology of restoration: historical links, emerging issues and unexplored realms. Ecology Letters 8:662–673 https://doi.org/10.1111/j.1461-0248.2005.00764.x

### Figures ######

aetr <- ggplot(paul_cov, aes(Type, AETR, colour = Type )) +
  geom_boxplot() +
  geom_point(position = position_jitterdodge(), alpha= 0.5) +
  theme_classic() +
  ylab("Aegilops triuncialis Cover") + theme(axis.title.y = element_text(size = 8, face="bold")) + theme(axis.title.x = element_text(face="bold"))

total_grass <- ggplot(grass, aes(Type, Total, colour = Type )) +
  geom_boxplot() +
  geom_point(position = position_jitterdodge(), alpha= 0.5) +
  theme_classic() +
  ylab("Total Annual Grass Cover") + theme(legend.position = "none") + theme(axis.title.y = element_text(size = 8, face="bold")) + theme(axis.title.x = element_text(face="bold"))

laca <- ggplot(paul_cov, aes(Type, LACA, colour = Type )) +
  geom_boxplot() +
  geom_point(position = position_jitterdodge(), alpha= 0.5) +
  theme_classic() +
  ylab("Lasthenia californica Cover") + theme(axis.title.y = element_text(size = 8, face="bold")) + theme(axis.title.x = element_text(face="bold"))

total_forb <- ggplot(poll_forb, aes(Type, Total, colour = Type )) +
  geom_boxplot() +
  geom_point(position = position_jitterdodge(), alpha= 0.5) +
  theme_classic() +
  ylab("Total Preferred Forb Cover") + theme(legend.position = "none") + theme(axis.title.y = element_text(size = 8, face="bold")) + theme(axis.title.x = element_text(face="bold"))

#quartz()
ggarrange(aetr, total_grass, laca, total_forb, 
          labels = c("A", "B", "C", "D"), 
          ncol = 2, nrow = 2) 



richness <- ggplot(paul_comm_plot, aes(Type, Plot_Richness, colour = Type)) + geom_boxplot() +
  geom_point(position = position_jitterdodge(), alpha= 0.5) +
  theme_classic() + ylab("Pollinator Richness") + theme(legend.position = "none") + theme(axis.title.y = element_text(size = 8, face="bold")) + theme(axis.title.x = element_text(face="bold"))


abund <- ggplot(paul_comm_plot, aes(Type, Abundance, colour = Type )) +
  geom_boxplot() +
  geom_point(position = position_jitterdodge(), alpha= 0.5) +
  theme_classic() + ylab("Total Pollinator Abundance") + theme(legend.position = "none") + theme(axis.title.y = element_text(size = 8, face="bold")) + theme(axis.title.x = element_text(face="bold"))

shannon_plot <- ggplot(paul_comm_plot, aes(Type, shannon, colour = Type )) +
  geom_boxplot() +
  geom_point(position = position_jitterdodge(), alpha= 0.5) +
  theme_classic() + ylab("Pollinator Shannon Diversity") + theme(legend.position = "none") + theme(axis.title.y = element_text(size = 8, face="bold")) + theme(axis.title.x = element_text(face="bold"))


ground <- ggplot(ground_abund_plot_full, aes(Type, Ground_Abundance, colour = Type )) +
  geom_boxplot() +
  geom_point(position = position_jitterdodge(), alpha= 0.5) +
  theme_classic() + ylab("Ground Nesting Bee Abundance") + theme(legend.position = "none") + theme(axis.title.y = element_text(size = 8, face="bold")) + theme(axis.title.x = element_text(face="bold"))
#updated plot with zeros

ground_2 <- ggplot(ground_abund_plot_full, aes(Type, ground_prop, colour = Type )) +
  geom_boxplot() +
  geom_point(position = position_jitterdodge(), alpha= 0.5) +
  theme_classic() + ylab("Proportion Ground Nesting Bees") + theme(legend.position = "none") + theme(axis.title.y = element_text(size = 8, face="bold")) + theme(axis.title.x = element_text(face="bold"))

#use zoom function
ggarrange(richness, abund, shannon_plot, ground,
          labels = c("A", "B", "C", "D"),
          ncol = 2, nrow = 2)


